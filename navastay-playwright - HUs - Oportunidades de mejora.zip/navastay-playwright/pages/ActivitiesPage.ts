import { Locator, Page } from '@playwright/test';
import { CatalogPage } from './CatalogPage';

export class ActivitiesPage extends CatalogPage {
  readonly title = 'Actividades';
  readonly addButtonName = 'Agregar Actividad';
  readonly dialogTitle = 'Actividad';
  readonly knownValues = ['MANTENIMIENTO', 'SERVICIOS PÚBLICOS', 'SERVICIOS SUBCONTRATADOS', 'ACTIVIDAD PRUEBA'] as const;

  constructor(page: Page) { super(page); }

  get valueInput(): Locator {
    // El modal observado contiene un único campo de captura. Se evita asumir el Page Item APEX.
    return this.page.getByRole('dialog').getByRole('textbox').first()
      .or(this.page.locator('.ui-dialog:visible input, .ui-dialog:visible textarea').first());
  }
}
