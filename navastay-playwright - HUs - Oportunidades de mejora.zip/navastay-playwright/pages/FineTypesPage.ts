import { Locator, Page } from '@playwright/test';
import { CatalogPage } from './CatalogPage';

export class FineTypesPage extends CatalogPage {
  readonly title = 'Tipos de Multa';
  readonly addButtonName = 'Agregar Tipo de Multa';
  readonly dialogTitle = 'Tipos de Multa';
  readonly knownValues = ['ATRASO CUOTAS DE MANTENIMIENTO', 'FALTAS AL REGLAMENTO CON MASCOTAS', 'MAL USO DE ÁREAS COMUNES'] as const;

  constructor(page: Page) { super(page); }

  get valueInput(): Locator {
    return this.page.getByRole('dialog').getByRole('textbox').first()
      .or(this.page.locator('.ui-dialog:visible input, .ui-dialog:visible textarea').first());
  }
}
