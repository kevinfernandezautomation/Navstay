import { expect, Locator, Page } from '@playwright/test';

export abstract class CatalogPage {
  readonly page: Page;
  abstract readonly title: string;
  abstract readonly addButtonName: string;
  abstract readonly dialogTitle: string;
  abstract readonly knownValues: readonly string[];

  constructor(page: Page) { this.page = page; }

  get heading(): Locator { return this.page.getByText(this.title, { exact: true }).first(); }
  get searchInput(): Locator { return this.page.getByPlaceholder('Buscar').first(); }
  get goButton(): Locator { return this.page.getByRole('button', { name: 'Ir', exact: true }).first(); }
  get actionsButton(): Locator { return this.page.getByText('Acciones', { exact: true }).first(); }
  get addButton(): Locator { return this.page.getByRole('button', { name: this.addButtonName, exact: true }).first(); }
  get saveButton(): Locator { return this.page.getByRole('button', { name: 'Guardar', exact: true }).first(); }
  get backButton(): Locator { return this.page.getByRole('button', { name: 'Regresar', exact: true }).first(); }

  async verifyLoaded() {
    await expect(this.heading).toBeVisible();
    await expect(this.searchInput).toBeVisible();
    await expect(this.goButton).toBeVisible();
    await expect(this.actionsButton).toBeVisible();
    await expect(this.addButton).toBeVisible();
  }

  async verifyKnownRows() {
    for (const value of this.knownValues) {
      await expect(this.page.getByText(value, { exact: true }).first()).toBeVisible();
    }
  }

  async search(value: string) {
    await this.searchInput.fill(value);
    await this.goButton.click();
  }

  async openAddDialog() {
    await this.addButton.click();
    await expect(this.page.getByText(this.dialogTitle, { exact: true }).last()).toBeVisible();
    await expect(this.saveButton).toBeVisible();
    await expect(this.backButton).toBeVisible();
  }

  async closeWithoutSaving() {
    await this.backButton.click();
    await expect(this.saveButton).not.toBeVisible();
  }

  async verifyKeyboardReachability() {
    await this.searchInput.focus();
    await expect(this.searchInput).toBeFocused();
  }
}
