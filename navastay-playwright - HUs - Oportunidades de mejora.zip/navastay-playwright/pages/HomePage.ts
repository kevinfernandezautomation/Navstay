import { expect, Locator, Page } from '@playwright/test';

export class HomePage {
  readonly page: Page;
  readonly homeMenu: Locator;
  readonly generalMenu: Locator;
  readonly logout: Locator;
  readonly propertyContext: Locator;

  constructor(page: Page) {
    this.page = page;
    this.homeMenu = page.getByText('Home', { exact: true }).first();
    this.generalMenu = page.getByText('General', { exact: true }).first();
    this.logout = page.getByText('Salir', { exact: true }).first();
    this.propertyContext = page.getByText('PRUEBA SIR', { exact: true }).first();
  }

  async verifyLoaded() {
    await expect(this.page).toHaveURL(/\/home(?:\?|$)/);
    await expect(this.homeMenu).toBeVisible();
    await expect(this.generalMenu).toBeVisible();
    await expect(this.logout).toBeVisible();
  }

  async verifyDashboard() {
    const kpis = [
      'CASOS ACTIVOS', 'RESERVAS ACTIVAS',
      'FACTURAS DE VENTA REGISTRADAS', 'FACTURAS DE COMPRA REGISTRADAS',
    ];
    for (const label of kpis) {
      await expect(this.page.getByText(label, { exact: false }).first()).toBeVisible();
    }

    const shortcuts = [
      'Facturas de Venta', 'Recibos', 'Estados de Cuenta', 'Facturas de Compra',
      'Pagos', 'Facturas Pendientes', 'Reservas', 'Convocatorias', 'Actas',
    ];
    for (const label of shortcuts) {
      await expect(this.page.getByText(label, { exact: true }).first()).toBeVisible();
    }

    await expect(this.page.getByText('Ingresos vs. gastos', { exact: false }).first()).toBeVisible();
    await expect(this.page.getByText('Estado de facturas', { exact: false }).first()).toBeVisible();
    await expect(this.page.getByText('COLON', { exact: true }).first()).toBeVisible();
  }

  async openGeneralParameters() {
    await this.generalMenu.click();
    const parameters = this.page.getByText('Parámetros', { exact: true }).first();
    await expect(parameters).toBeVisible();
    await parameters.hover();
  }

  async goToActivityCatalog() {
    await this.openGeneralParameters();
    const item = this.page.getByText('Actividades', { exact: true }).first();
    await expect(item).toBeVisible();
    await item.click();
  }

  async goToFineTypeCatalog() {
    await this.openGeneralParameters();
    const item = this.page.getByText('Tipos de Multa', { exact: true }).first();
    await expect(item).toBeVisible();
    await item.click();
  }
}
