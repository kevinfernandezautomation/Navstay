import { test as base, expect, Page } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

export async function authenticate(page: Page): Promise<void> {
  const login = new LoginPage(page);
  await login.goto();
  await login.verifyLoginPage();
  await login.loginWithValidCredentials();
  await expect(page).toHaveURL(/\/home(?:\?|$)/, { timeout: 20_000 });
}

export const test = base.extend<{ authenticatedPage: Page }>({
  authenticatedPage: async ({ page }, use) => {
    await authenticate(page);
    await use(page);
  },
});

export { expect } from '@playwright/test';
