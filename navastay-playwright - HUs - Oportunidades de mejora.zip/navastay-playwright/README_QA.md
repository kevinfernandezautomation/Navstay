# Navastay - automatización Playwright ampliada

Cobertura implementada a partir de las historias de usuario y capturas suministradas:
- Login: funcional, negativo, seguridad funcional y accesibilidad básica.
- Home/Dashboard: navegación, KPIs, accesos funcionales, gráficos, moneda y contexto visible.
- Actividades: acceso, listado, búsqueda, modal de alta, captura no destructiva y foco.
- Tipos de Multa: acceso, listado, búsqueda, modal de alta, captura no destructiva y foco.

## Principio de seguridad de datos
Las HU indican que las reglas de persistencia, validación, duplicados y permisos aún son información faltante. Por eso las nuevas pruebas NO pulsan Guardar ni modifican registros reales. Se valida el flujo hasta la captura y se sale mediante Regresar.

## Ejecución
1. Copiar `.env.example` a `.env` y completar credenciales de prueba.
2. `npm install`
3. `npx playwright install`
4. `npm test`
5. `npm run test:chromium` para ejecución rápida en Chromium.
6. `npm run report` para abrir el reporte HTML.

## Próxima expansión
Cuando Product/BA confirme reglas de Guardar, edición, duplicados, permisos y oráculos de BD, añadir pruebas de persistencia, autorización, concurrencia y consistencia UI-BD sin asumir reglas no documentadas.
