import { test, expect } from '../fixtures/auth.fixture';
import { HomePage } from '../pages/HomePage';

test.describe('HU-HOME-001 - Dashboard principal', () => {
  test('HOME-001 - Presenta Dashboard y navegación principal', async ({ authenticatedPage: page }) => {
    const home = new HomePage(page);
    await home.verifyLoaded();
  });

  test('HOME-002 - Presenta los cuatro indicadores definidos en la HU', async ({ authenticatedPage: page }) => {
    const home = new HomePage(page);
    await home.verifyDashboard();
  });

  test('HOME-003 - Contexto de inmueble observado está visible', async ({ authenticatedPage: page }) => {
    const home = new HomePage(page);
    await expect(home.propertyContext).toBeVisible();
  });

  test('HOME-004 - Menú General expone Parámetros', async ({ authenticatedPage: page }) => {
    const home = new HomePage(page);
    await home.openGeneralParameters();
    await expect(page.getByText('Actividades', { exact: true }).first()).toBeVisible();
    await expect(page.getByText('Tipos de Multa', { exact: true }).first()).toBeVisible();
  });
});
