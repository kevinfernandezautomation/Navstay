import { test, expect } from '../fixtures/auth.fixture';
import { HomePage } from '../pages/HomePage';
import { ActivitiesPage } from '../pages/ActivitiesPage';

test.describe('HU-PAR-ACT-001 - Catálogo Actividades', () => {
  test.beforeEach(async ({ authenticatedPage: page }) => {
    await new HomePage(page).goToActivityCatalog();
  });

  test('ACT-001 - Acceso y controles principales', async ({ authenticatedPage: page }) => {
    await new ActivitiesPage(page).verifyLoaded();
  });

  test('ACT-002 - Muestra registros observados en la evidencia', async ({ authenticatedPage: page }) => {
    await new ActivitiesPage(page).verifyKnownRows();
  });

  test('ACT-003 - Buscar actividad conocida', async ({ authenticatedPage: page }) => {
    const activities = new ActivitiesPage(page);
    await activities.search('MANTENIMIENTO');
    await expect(page.getByText('MANTENIMIENTO', { exact: true }).first()).toBeVisible();
  });

  test('ACT-004 - Abrir modal Agregar Actividad', async ({ authenticatedPage: page }) => {
    const activities = new ActivitiesPage(page);
    await activities.openAddDialog();
    await expect(activities.valueInput).toBeVisible();
  });

  test('ACT-005 - Capturar dato y regresar sin ejecutar Guardar', async ({ authenticatedPage: page }) => {
    const activities = new ActivitiesPage(page);
    await activities.openAddDialog();
    await activities.valueInput.fill('QA ACTIVIDAD TEMPORAL');
    await expect(activities.valueInput).toHaveValue('QA ACTIVIDAD TEMPORAL');
    await activities.closeWithoutSaving();
  });

  test('ACT-006 - Campo de búsqueda puede recibir foco', async ({ authenticatedPage: page }) => {
    await new ActivitiesPage(page).verifyKeyboardReachability();
  });
});
