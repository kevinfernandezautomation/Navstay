import { test, expect } from '../fixtures/auth.fixture';
import { HomePage } from '../pages/HomePage';
import { FineTypesPage } from '../pages/FineTypesPage';

test.describe('HU-PAR-TM-001 - Tipos de Multa', () => {
  test.beforeEach(async ({ authenticatedPage: page }) => {
    await new HomePage(page).goToFineTypeCatalog();
  });

  test('TM-001 - Acceso y controles principales', async ({ authenticatedPage: page }) => {
    await new FineTypesPage(page).verifyLoaded();
  });

  test('TM-002 - Muestra registros observados en la evidencia', async ({ authenticatedPage: page }) => {
    await new FineTypesPage(page).verifyKnownRows();
  });

  test('TM-003 - Buscar tipo de multa conocido', async ({ authenticatedPage: page }) => {
    const fines = new FineTypesPage(page);
    await fines.search('ATRASO CUOTAS DE MANTENIMIENTO');
    await expect(page.getByText('ATRASO CUOTAS DE MANTENIMIENTO', { exact: true }).first()).toBeVisible();
  });

  test('TM-004 - Abrir modal Agregar Tipo de Multa', async ({ authenticatedPage: page }) => {
    const fines = new FineTypesPage(page);
    await fines.openAddDialog();
    await expect(fines.valueInput).toBeVisible();
  });

  test('TM-005 - Capturar dato y regresar sin ejecutar Guardar', async ({ authenticatedPage: page }) => {
    const fines = new FineTypesPage(page);
    await fines.openAddDialog();
    await fines.valueInput.fill('QA TIPO MULTA TEMPORAL');
    await expect(fines.valueInput).toHaveValue('QA TIPO MULTA TEMPORAL');
    await fines.closeWithoutSaving();
  });

  test('TM-006 - Campo de búsqueda puede recibir foco', async ({ authenticatedPage: page }) => {
    await new FineTypesPage(page).verifyKeyboardReachability();
  });
});
